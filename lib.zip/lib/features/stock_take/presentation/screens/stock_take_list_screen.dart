// Stock Take List Screen (Read‑Only)
import 'package:flutter/material.dart';
import '../../data/api_stock_take_repository.dart';
import '../../data/stock_take_repository.dart';
import '../../models/stock_take.dart';
import '../../../../core/routes/app_routes.dart';
import '../../../../core/api/api_client.dart';
import '../widgets/stock_take_card.dart';
import 'package:stocklite/features/kho/models/inventory_stock.dart' show WarehouseOption;
import 'package:stocklite/features/kho/data/stock_take_repository.dart' as legacy_repo;

class StockTakeListScreen extends StatefulWidget {
  const StockTakeListScreen({this.repository, this.legacyRepository, super.key});

  final StockTakeRepository? repository;
  final legacy_repo.StockTakeRepository? legacyRepository;

  @override
  State<StockTakeListScreen> createState() => _StockTakeListScreenState();
}

class _StockTakeListScreenState extends State<StockTakeListScreen> {
  late final StockTakeRepository _repo;
  final List<StockTakeSummary> _items = [];
  bool _isLoading = false;
  bool _hasMore = true;
  int _start = 0;
  final int _length = 20;
  String _search = '';
  int? _selectedWarehouse;
  String? _selectedStatus;

  @override
  void initState() {
    super.initState();
    _repo = widget.repository ?? (widget.legacyRepository as StockTakeRepository? ?? ApiStockTakeRepository());
    _loadPage();
  }

  Future<void> _loadPage({bool reset = false}) async {
    if (_isLoading) return;
    setState(() => _isLoading = true);
    if (reset) {
      _start = 0;
      _items.clear();
      _hasMore = true;
    }
    try {
      final page = await _repo.getStockTakesPaged(
        start: _start,
        length: _length,
        search: _search,
        warehouseId: _selectedWarehouse,
        statusCode: _selectedStatus,
      );
      _items.addAll(page.items);
      _hasMore = _items.length < page.recordsTotal;
      _start += _length;
    } on ApiException catch (e) {
      // Show error snackbar
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi: ${e.message} (code ${e.statusCode})')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _refresh() async {
    await _loadPage(reset: true);
  }

  Widget _buildFilters() {
    // Warehouse options are fetched lazily; for brevity we use a placeholder list.
    // In a full implementation you would fetch via repository.getWarehouses().
    final warehouseItems = <DropdownMenuItem<int>>[
      const DropdownMenuItem(value: null, child: Text('Tất cả kho')),
      const DropdownMenuItem(value: 1, child: Text('Kho 1')),
      const DropdownMenuItem(value: 2, child: Text('Kho 2')),
    ];
    final statusItems = <DropdownMenuItem<String>>[
      const DropdownMenuItem(value: null, child: Text('Tất cả trạng thái')),
      const DropdownMenuItem(value: 'DRAFT', child: Text('Draft')),
      const DropdownMenuItem(value: 'COUNTING', child: Text('Counting')),
      const DropdownMenuItem(value: 'SUBMITTED', child: Text('Submitted')),
      const DropdownMenuItem(value: 'APPROVED', child: Text('Approved')),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: DropdownButton<int>(
              isExpanded: true,
              value: _selectedWarehouse,
              hint: const Text('Kho'),
              items: warehouseItems,
              onChanged: (v) => setState(() => _selectedWarehouse = v),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: DropdownButton<String>(
              isExpanded: true,
              value: _selectedStatus,
              hint: const Text('Trạng thái'),
              items: statusItems,
              onChanged: (v) => setState(() => _selectedStatus = v),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openDetail(int id) async {
    await Navigator.pushNamed(
      context,
      AppRoutes.stockTakeDetail,
      arguments: id,
    );
    _refresh();
  }

  Future<void> _createStockTake() async {
    final created = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      useRootNavigator: false,
      builder: (sheetContext) => _CreateStockTakeSheet(repository: _repo),
    );
    if (created != null && created > 0 && mounted) {
      await _openDetail(created);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Danh sách Kiểm kê kho'),
        backgroundColor: const Color(0xFF1976D2), // premium blue gradient could be added via decoration
      ),
      body: Column(
        children: [
          _buildFilters(),
          Expanded(
            child: _items.isEmpty
                ? const Center(
                    child: Text('Chưa có phiếu kiểm kê'),
                  )
                : RefreshIndicator(
                    onRefresh: _refresh,
                    child: ListView.builder(
                      itemCount: _items.length + (_hasMore ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index < _items.length) {
                          final item = _items[index];
                          return StockTakeCard(
                            summary: item,
                            onTap: () => _openDetail(item.id),
                          );
                        }
                        // Load more indicator
                        _loadPage();
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          child: Center(child: CircularProgressIndicator()),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createStockTake,
        backgroundColor: const Color(0xFF1976D2),
        icon: const Icon(Icons.add),
        label: const Text('Phiếu mới'),
      ),
    );
  }
}

class _CreateStockTakeSheet extends StatefulWidget {
  const _CreateStockTakeSheet({required this.repository});

  final StockTakeRepository repository;

  @override
  State<_CreateStockTakeSheet> createState() => _CreateStockTakeSheetState();
}

class _CreateStockTakeSheetState extends State<_CreateStockTakeSheet> {
  final TextEditingController _noteController = TextEditingController();

  List<WarehouseOption> _warehouses = const [];
  List<StockTakeLocationOption> _locations = const [];
  int? _warehouseId;
  StockTakeScope _scope = StockTakeScope.column;
  String? _zoneName;
  int? _locationId;
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadWarehouses();
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _loadWarehouses() async {
    try {
      final warehouses = await widget.repository.getWarehouses();
      if (!mounted) return;
      setState(() {
        _warehouses = warehouses;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = '$error';
        _loading = false;
      });
    }
  }

  Future<void> _loadLocations(int warehouseId) async {
    final locations = await widget.repository.getLocations(warehouseId);
    if (!mounted) return;
    setState(() {
      _locations = locations;
      _locationId = null;
      _zoneName = null;
    });
  }

  List<String> get _zones =>
      {for (final l in _locations) if (l.zoneName.isNotEmpty) l.zoneName}.toList()
        ..sort();

  Future<void> _submit() async {
    if (_warehouseId == null) {
      setState(() => _error = 'Vui lòng chọn kho.');
      return;
    }
    if (_scope == StockTakeScope.zone && (_zoneName ?? '').isEmpty) {
      setState(() => _error = 'Vui lòng chọn khu cần kiểm.');
      return;
    }
    if (_scope == StockTakeScope.column && _locationId == null) {
      setState(() => _error = 'Vui lòng chọn cột cần kiểm.');
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      final id = await widget.repository.create(
        warehouseId: _warehouseId!,
        scope: _scope,
        zoneName: _scope == StockTakeScope.zone ? _zoneName : null,
        locationId: _scope == StockTakeScope.column ? _locationId : null,
        note: _noteController.text,
      );
      if (!mounted) return;
      Navigator.of(context).pop(id);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = '$error';
        _saving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
            16, 4, 16, MediaQuery.viewInsetsOf(context).bottom + 16),
        child: _loading
            ? const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: CircularProgressIndicator()),
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Tạo phiếu kiểm kê',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  const Text(
                    'Backend sẽ chụp snapshot tồn kho tại thời điểm tạo phiên.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<int>(
                    key: const Key('warehouseDropdown'),
                    value: _warehouseId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Kho *',
                      prefixIcon: Icon(Icons.warehouse_outlined),
                    ),
                    items: [
                      for (final w in _warehouses)
                        DropdownMenuItem(value: w.id, child: Text(w.name)),
                    ],
                    onChanged: _saving
                        ? null
                        : (value) {
                            if (value == null) return;
                            setState(() => _warehouseId = value);
                            _loadLocations(value);
                          },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<StockTakeScope>(
                    key: const Key('scopeDropdown'),
                    value: _scope,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Phạm vi *',
                      prefixIcon: Icon(Icons.crop_free_rounded),
                    ),
                    items: [
                      for (final scope in StockTakeScope.values)
                        DropdownMenuItem(value: scope, child: Text(scope.label)),
                    ],
                    onChanged: _saving
                        ? null
                        : (value) => setState(() {
                              _scope = value ?? StockTakeScope.column;
                              _zoneName = null;
                              _locationId = null;
                            }),
                  ),
                  if (_scope == StockTakeScope.zone) ...[
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      key: const Key('zoneDropdown'),
                      value: _zoneName,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Khu *',
                        prefixIcon: Icon(Icons.grid_view_rounded),
                      ),
                      items: [
                        for (final zone in _zones)
                          DropdownMenuItem(value: zone, child: Text(zone)),
                      ],
                      onChanged: _saving
                          ? null
                          : (value) => setState(() => _zoneName = value),
                    ),
                  ],
                  if (_scope == StockTakeScope.column) ...[
                    const SizedBox(height: 12),
                    DropdownButtonFormField<int>(
                      key: const Key('columnDropdown'),
                      value: _locationId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Cột *',
                        prefixIcon: Icon(Icons.place_outlined),
                      ),
                      items: [
                        for (final location in _locations)
                          DropdownMenuItem(
                            value: location.id,
                            child: Text(location.label,
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                      ],
                      onChanged: _saving
                          ? null
                          : (value) => setState(() => _locationId = value),
                    ),
                  ],
                  const SizedBox(height: 12),
                  TextField(
                    key: const Key('noteField'),
                    controller: _noteController,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'Ghi chú',
                      hintText: 'Lý do hoặc hướng dẫn kiểm kê',
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Text(_error!,
                        style: const TextStyle(
                            color: Colors.redAccent, fontWeight: FontWeight.w700)),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    key: const Key('submitButton'),
                    onPressed: _saving ? null : _submit,
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF1976D2),
                      minimumSize: const Size.fromHeight(48),
                    ),
                    child: _saving
                        ? const SizedBox.square(
                            dimension: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white),
                          )
                        : const Text('Chụp tồn & bắt đầu kiểm'),
                  ),
                ],
              ),
      ),
    );
  }
}
