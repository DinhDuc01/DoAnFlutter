import '../../kho/models/inventory_stock.dart';
import '../models/stock_take.dart';
import '../../kho/models/stock_take.dart' as legacy;

/// Phạm vi chụp phiếu kiểm kê.
enum StockTakeScope { warehouse, zone, column }

extension StockTakeScopeX on StockTakeScope {
  String get code => switch (this) {
        StockTakeScope.warehouse => 'WAREHOUSE',
        StockTakeScope.zone => 'ZONE',
        StockTakeScope.column => 'COLUMN',
      };

  String get label => switch (this) {
        StockTakeScope.warehouse => 'Toàn kho',
        StockTakeScope.zone => 'Theo khu',
        StockTakeScope.column => 'Theo cột',
      };
}

/// Một cột/vị trí để chọn phạm vi kiểm kê.
class StockTakeLocationOption {
  const StockTakeLocationOption({
    required this.id,
    required this.warehouseId,
    required this.zoneName,
    required this.label,
  });

  final int id;
  final int warehouseId;
  final String zoneName;
  final String label;
}

abstract class StockTakeRepository {
  Future<StockTakePage> getStockTakesPaged({
    required int start,
    required int length,
    String? search,
    int? warehouseId,
    String? statusCode,
  });

  Future<legacy.StockTakeDetail> getStockTakeDetail(int id);
  Future<List<WarehouseOption>> getWarehouses();
  Future<List<StockTakeLocationOption>> getLocations(int warehouseId);

  Future<int> create({
    required int warehouseId,
    required StockTakeScope scope,
    String? zoneName,
    int? locationId,
    String? note,
  });
}
