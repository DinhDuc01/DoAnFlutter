import 'package:flutter/material.dart';

import '../../data/milling_repository.dart';
import '../../models/milling_order.dart';
import '../../models/milling_output_form.dart';
import '../../../scale/models/weight_reading.dart';
import '../../../scale/presentation/screens/scale_screen.dart';
import '../widgets/milling_widgets.dart';
import 'bran_weighing_screen.dart';

/// Displays live scale data and the recorded finished-rice bags.
class RiceWeighingScreen extends StatefulWidget {
  const RiceWeighingScreen({
    required this.order,
    required this.repository,
    this.includeBroken = false,
    this.initialOutputForms = const [],
    super.key,
  });

  final MillingOrder order;
  final MillingRepository repository;
  final bool includeBroken;
  final List<MillingOutputFormValue> initialOutputForms;

  @override
  State<RiceWeighingScreen> createState() => _RiceWeighingScreenState();
}

class _RiceWeighingScreenState extends State<RiceWeighingScreen> {
  bool _isSaving = false;
  late List<MillingBag> _bags;
  double? _latestWeightKg;
  late MillingScaleMode _scaleMode;
  late List<MillingOutputFormValue> _outputForms;

  @override
  void initState() {
    super.initState();
    _bags = List<MillingBag>.of(widget.order.riceBags);
    _scaleMode = widget.order.scaleMode;
    _outputForms = List.unmodifiable(widget.initialOutputForms);
  }

  MillingOrder get _currentOrder => widget.order.copyWith(
        riceBags: _bags,
        scaleMode: _scaleMode,
      );

  Future<void> _captureWeight() async {
    final double? weight;
    if (_scaleMode == MillingScaleMode.iot) {
      final reading = await Navigator.of(context).push<WeightReading>(
        MaterialPageRoute(builder: (_) => const ScaleScreen()),
      );
      weight = reading?.weight;
    } else {
      weight = await showManualWeightDialog(context, productLabel: 'gạo');
    }
    if (!mounted || weight == null || !weight.isFinite || weight <= 0) return;
    final capturedWeight = weight;
    setState(() {
      _latestWeightKg = capturedWeight;
      _bags = [
        ..._bags,
        MillingBag(index: _bags.length + 1, weightKg: capturedWeight),
      ];
    });
  }

  Future<void> _continue() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => BranWeighingScreen(
          order: _currentOrder,
          repository: widget.repository,
          includeBroken: widget.includeBroken,
          initialOutputForms: upsertMillingOutput(
            _outputForms,
            adaptLegacyMillingOutputs([
              LegacyMillingOutputInput(
                type: MillingOutputType.rice,
                productVariantId: _currentOrder.riceProductVariantId,
                bagWeightsKg: _bags.map((bag) => bag.weightKg).toList(),
              ),
            ]).single,
          ),
        ),
      ),
    );
    if (mounted) setState(() => _isSaving = false);
  }

  @override
  Widget build(BuildContext context) {
    final bags = _bags;
    final order = _currentOrder;
    return Scaffold(
      backgroundColor: millingBackground,
      appBar: const MillingAppBar(title: 'Cân gạo sau xay'),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
        children: [
          BleScaleCaptureCard(
            scaleCode: widget.order.scaleCode,
            latestWeightKg: _latestWeightKg,
            instruction: 'Đặt bao gạo thành phẩm lên cân rồi nhận số ổn định.',
            onCapture: _captureWeight,
            manualMode: _scaleMode == MillingScaleMode.manual,
            onModeChanged: (manual) => setState(() {
              _scaleMode = manual ? MillingScaleMode.manual : MillingScaleMode.iot;
            }),
          ),
          const SizedBox(height: 10),
          WeighingSummary(
            bagCount: bags.length,
            totalWeightKg: order.totalRiceKg,
            productLabel: 'gạo',
          ),
          const SizedBox(height: 10),
          BagListCard(bags: bags, label: 'Bao gạo'),
        ],
      ),
      bottomNavigationBar: MillingPrimaryButton(
        label: 'Tiếp tục cân cám',
        isLoading: _isSaving,
        onPressed: bags.isEmpty ? null : _continue,
      ),
    );
  }
}
